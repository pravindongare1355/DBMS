function fun()
{
    let x = document.getElementById("#input").value; 

    if(x == "")                                     //to validate empty field
    {
        alert("Please Enter valid username");
    }

    let y =  document.getElementById("#password").value;
 
    if(y == "")                                    //to validate empty field
    {
        alert("Please Enter valid password");
    }



    let a = document.querySelector("#input").value;       // for printing details on page

    let b = document.querySelector("#password").value;   // for printing details on page

    let c = a + "" + b;                                  // concat both element

    let chipkao = document.querySelector("#chipkao"); // for printing details on page

    chipkao.children[0].innerHTML=c;      //final display output





// let displayFunction = input "" + "" password;

//       let z.children[0].innerHTML = displayFunction; 


    document.getElementById("#input")=""; //for clear field

    document.getElementById("#password")=""; //for clear field


}